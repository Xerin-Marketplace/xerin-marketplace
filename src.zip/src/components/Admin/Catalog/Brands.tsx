"use client";
import { FormEvent,useEffect,useState } from "react";import { Edit3,Plus,RefreshCw,Search,Trash2,X } from "lucide-react";import toast from "react-hot-toast";import {adminService,type Brand} from "@/lib/api/endpoints/admin";
import { ConfirmActionDialog } from "@/components/Admin/shared/ActionDialog";
const slugify=(v:string)=>v.toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"");
export default function AdminBrands(){const[rows,setRows]=useState<Brand[]>([]);const[loading,setLoading]=useState(true);const[error,setError]=useState("");const[name,setName]=useState("");const[slug,setSlug]=useState("");const[busy,setBusy]=useState(false);const[query,setQuery]=useState("");const[debouncedQuery,setDebouncedQuery]=useState("");const[page,setPage]=useState(1);const[pageSize,setPageSize]=useState(20);const[total,setTotal]=useState(0);const[totalPages,setTotalPages]=useState(0);const[editing,setEditing]=useState<Brand|null>(null);const[deleteTarget,setDeleteTarget]=useState<Brand|null>(null);
const load=async()=>{setLoading(true);setError("");try{const r=await adminService.listBrandsPaginated({page,page_size:pageSize,search:debouncedQuery||undefined});setRows(r.results);setTotal(r.total);setTotalPages(r.total_pages)}catch(e){setError(e instanceof Error?e.message:"Unable to load brands.")}finally{setLoading(false)}};useEffect(()=>{const t=window.setTimeout(()=>{setDebouncedQuery(query.trim());setPage(1)},350);return()=>window.clearTimeout(t)},[query]);useEffect(()=>{void load();/* eslint-disable-next-line react-hooks/exhaustive-deps */},[page,pageSize,debouncedQuery]);
const submit=async(e:FormEvent)=>{e.preventDefault();if(!name.trim())return;setBusy(true);try{await adminService.createBrand({name:name.trim(),slug:slug.trim()||slugify(name)});setName("");setSlug("");toast.success("Brand created.");await load()}catch(x){toast.error(x instanceof Error?x.message:"Unable to create brand.")}finally{setBusy(false)}};const save=async()=>{if(!editing)return;setBusy(true);try{await adminService.updateBrand(editing.id,{name:editing.name,slug:editing.slug});toast.success("Brand updated.");setEditing(null);await load()}catch(x){toast.error(x instanceof Error?x.message:"Unable to update brand.")}finally{setBusy(false)}};const remove=async()=>{if(!deleteTarget)return;setBusy(true);try{await adminService.deleteBrand(deleteTarget.id);toast.success("Brand deleted.");setDeleteTarget(null);await load()}catch(x){toast.error(x instanceof Error?x.message:"Unable to delete brand.")}finally{setBusy(false)}};
return <div className="admin-catalog-page space-y-5">
<section className="admin-catalog-header">
<h2 className="text-2xl font-bold">Brand Management</h2>
<p className="mt-1 text-sm text-gray-500">Backend-controlled search and pagination.</p>
</section>
<div className="grid gap-5 xl:grid-cols-[360px_minmax(0,1fr)]">
<form onSubmit={submit} className="admin-catalog-form">
<h3 className="font-bold">Add New Brand</h3>
<Field label="Brand name">
<input className="field" value={name} onChange={e=>{setName(e.target.value);if(!slug)setSlug(slugify(e.target.value))}}/>
</Field>
<Field label="Slug">
<input className="field" value={slug} onChange={e=>setSlug(slugify(e.target.value))}/>
</Field>
<button disabled={busy||!name.trim()} className="mt-5 w-full rounded-xl bg-[#111827] py-3 font-semibold text-white">
<Plus className="mr-2 inline" size={14}/>Add Brand</button>
</form>
<section className="admin-catalog-card overflow-hidden">
<div className="admin-catalog-toolbar">
<div className="relative flex-1">
<Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2"/>
<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search brands..." className="h-10 w-full rounded-xl border pl-9 pr-3"/>
</div>
<button onClick={()=>void load()} className="rounded-xl border px-3">
<RefreshCw size={15}/>
</button>
</div>{loading?<p className="p-10 text-center">Loading...</p>:error?<p className="p-10 text-center text-red-600">{error}</p>:!rows.length?<p className="p-10 text-center">No matching brands.</p>:<div className="overflow-x-auto">
<table className="w-full min-w-[680px] text-left text-sm">
<thead className="bg-gray-50">
<tr>
<th className="px-5 py-3">Name</th>
<th className="px-5 py-3">Slug</th>
<th className="px-5 py-3">Created</th>
<th className="px-5 py-3">Actions</th>
</tr>
</thead>
<tbody className="divide-y">{rows.map(r=>
<tr key={r.id}>
<td className="px-5 py-4 font-semibold">{r.name}</td>
<td className="px-5 py-4 text-gray-500">{r.slug}</td>
<td className="px-5 py-4 text-gray-500">{new Date(r.created_at).toLocaleDateString()}</td>
<td className="px-5 py-4">
<button onClick={()=>setEditing({...r})} className="mr-4 text-blue-600">
<Edit3 className="inline" size={13}/> Edit</button>
<button onClick={()=>setDeleteTarget(r)} className="text-red-600">
<Trash2 className="inline" size={13}/> Delete</button>
</td>
</tr>)}</tbody>
</table>
</div>}<Pagination page={page} pageSize={pageSize} total={total} totalPages={totalPages} onPageChange={setPage} onPageSizeChange={s=>{setPageSize(s);setPage(1)}}/>
</section>
</div>{editing&&<div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4">
<div className="w-full max-w-md rounded-2xl bg-white p-6">
<div className="flex justify-between">
<h3 className="font-bold">Edit Brand</h3>
<button onClick={()=>setEditing(null)}>
<X size={18}/>
</button>
</div>
<Field label="Name">
<input className="field" value={editing.name} onChange={e=>setEditing(c=>c?{...c,name:e.target.value}:c)}/>
</Field>
<Field label="Slug">
<input className="field" value={editing.slug} onChange={e=>setEditing(c=>c?{...c,slug:e.target.value}:c)}/>
</Field>
<button onClick={()=>void save()} disabled={busy} className="mt-5 w-full rounded-xl bg-[#111827] py-3 font-semibold text-white">Save Changes</button>
</div>
</div>}<ConfirmActionDialog open={Boolean(deleteTarget)} title="Delete brand?" description={<>The brand <strong>{deleteTarget?.name}</strong> will be permanently deleted. Products using it may prevent this action.</>} confirmLabel="Delete brand" busy={busy} onCancel={()=>setDeleteTarget(null)} onConfirm={()=>void remove()}/><style jsx global>{`.field{margin-top:.5rem;min-height:46px;width:100%;border-radius:.75rem;border:2px solid #d8e0e9;background:#fff;padding:.7rem .9rem;outline:none}.field:focus{border-color:#f47524}`}</style>
</div>}
function Pagination({page,pageSize,total,totalPages,onPageChange,onPageSizeChange}:{page:number;pageSize:number;total:number;totalPages:number;onPageChange:(n:number)=>void;onPageSizeChange:(n:number)=>void}){const a=total?((page-1)*pageSize+1):0,b=Math.min(page*pageSize,total);return <div className="flex flex-col gap-3 border-t p-4 sm:flex-row sm:items-center sm:justify-between">
<span className="text-sm">Showing {a}-{b} of {total}</span>
<div className="flex gap-2">
<select value={pageSize} onChange={e=>onPageSizeChange(Number(e.target.value))} className="rounded-xl border px-2">{[10,20,50,100].map(x=>
<option key={x}>{x}</option>)}</select>
<button disabled={page<=1} onClick={()=>onPageChange(page-1)} className="rounded-xl border px-3 disabled:opacity-40">Previous</button>
<span className="px-2 py-2 text-xs">Page {page} of {Math.max(totalPages,1)}</span>
<button disabled={page>=totalPages||!totalPages} onClick={()=>onPageChange(page+1)} className="rounded-xl border px-3 disabled:opacity-40">Next</button>
</div>
</div>}
function Field({label,children}:{label:string;children:React.ReactNode}){return <label className="mt-4 block">
<span className="text-sm font-semibold">{label}</span>{children}</label>}
