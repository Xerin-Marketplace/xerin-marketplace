"use client";
import { FormEvent, useEffect, useState } from "react";
import { Edit3, Plus, RefreshCw, Search, Trash2, X } from "lucide-react";
import toast from "react-hot-toast";
import { adminService, type BusinessCategory, type ProductCategory } from "@/lib/api/endpoints/admin";
import { ConfirmActionDialog } from "@/components/Admin/shared/ActionDialog";
type Mode="product"|"business";type Editing={type:"product";row:ProductCategory}|{type:"business";row:BusinessCategory}|null;
const slugify=(v:string)=>v.toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"");
export default function AdminCategories(){
 const[mode,setMode]=useState<Mode>("product");const[productRows,setProductRows]=useState<ProductCategory[]>([]);const[businessRows,setBusinessRows]=useState<BusinessCategory[]>([]);const[loading,setLoading]=useState(true);const[error,setError]=useState("");const[busy,setBusy]=useState(false);const[query,setQuery]=useState("");const[debouncedQuery,setDebouncedQuery]=useState("");const[page,setPage]=useState(1);const[pageSize,setPageSize]=useState(20);const[total,setTotal]=useState(0);const[totalPages,setTotalPages]=useState(0);const[editing,setEditing]=useState<Editing>(null);const[deleteTarget,setDeleteTarget]=useState<{row:ProductCategory|BusinessCategory;type:Mode}|null>(null);
 const[productForm,setProductForm]=useState({name:"",slug:"",parent_id:""});const[businessForm,setBusinessForm]=useState({name:"",slug:"",description:"",active:true});
 const load=async()=>{setLoading(true);setError("");try{if(mode==="product"){const r=await adminService.listProductCategoriesPaginated({page,page_size:pageSize,search:debouncedQuery||undefined});setProductRows(r.results);setTotal(r.total);setTotalPages(r.total_pages);}else{const r=await adminService.listBusinessCategoriesPaginated({page,page_size:pageSize,search:debouncedQuery||undefined,active_filter:"all"});setBusinessRows(r.results);setTotal(r.total);setTotalPages(r.total_pages);}}catch(e){setError(e instanceof Error?e.message:"Unable to load categories.");}finally{setLoading(false)}};
 useEffect(()=>{const t=window.setTimeout(()=>{setDebouncedQuery(query.trim());setPage(1)},350);return()=>window.clearTimeout(t)},[query]);useEffect(()=>{void load();/* eslint-disable-next-line react-hooks/exhaustive-deps */},[mode,page,pageSize,debouncedQuery]);useEffect(()=>{setPage(1);setQuery("");setDebouncedQuery("")},[mode]);
 const createProduct=async(e:FormEvent)=>{e.preventDefault();if(!productForm.name.trim())return;setBusy(true);try{await adminService.createProductCategory({name:productForm.name.trim(),slug:productForm.slug.trim()||slugify(productForm.name),parent_id:productForm.parent_id||null});setProductForm({name:"",slug:"",parent_id:""});toast.success("Product category created.");await load()}catch(x){toast.error(x instanceof Error?x.message:"Unable to create category.")}finally{setBusy(false)}};
 const createBusiness=async(e:FormEvent)=>{e.preventDefault();if(!businessForm.name.trim())return;setBusy(true);try{await adminService.createBusinessCategory({name:businessForm.name.trim(),slug:businessForm.slug.trim()||slugify(businessForm.name),description:businessForm.description.trim()||undefined,active:businessForm.active});setBusinessForm({name:"",slug:"",description:"",active:true});toast.success("Business category created.");await load()}catch(x){toast.error(x instanceof Error?x.message:"Unable to create business category.")}finally{setBusy(false)}};
 const save=async()=>{if(!editing)return;setBusy(true);try{if(editing.type==="product")await adminService.updateProductCategory(editing.row.id,{name:editing.row.name,slug:editing.row.slug,parent_id:editing.row.parent_id??null});else await adminService.updateBusinessCategory(editing.row.id,{name:editing.row.name,slug:editing.row.slug,description:editing.row.description??undefined,active:editing.row.active});toast.success("Category updated.");setEditing(null);await load()}catch(x){toast.error(x instanceof Error?x.message:"Unable to update category.")}finally{setBusy(false)}};
 const remove=async()=>{if(!deleteTarget)return;setBusy(true);try{deleteTarget.type==="product"?await adminService.deleteProductCategory(deleteTarget.row.id):await adminService.deleteBusinessCategory(deleteTarget.row.id);toast.success("Category deleted.");setDeleteTarget(null);await load()}catch(x){toast.error(x instanceof Error?x.message:"Unable to delete category.")}finally{setBusy(false)}};
 return <div className="admin-catalog-page space-y-5">
<section className="admin-catalog-header">
<h2 className="text-2xl font-bold">Category Management</h2>
<p className="mt-1 text-sm text-gray-500">Backend-controlled search and pagination.</p>
<div className="mt-4 inline-flex rounded-xl border bg-gray-50 p-1">
<button onClick={()=>setMode("product")} className={`rounded-lg px-4 py-2 text-sm font-semibold ${mode==="product"?"bg-white shadow-sm":"text-gray-500"}`}>Product Categories</button>
<button onClick={()=>setMode("business")} className={`rounded-lg px-4 py-2 text-sm font-semibold ${mode==="business"?"bg-white shadow-sm":"text-gray-500"}`}>Business Categories</button>
</div>
</section>
<div className="grid gap-5 xl:grid-cols-[360px_minmax(0,1fr)]">{mode==="product"?<form onSubmit={createProduct} className="admin-catalog-form">
<h3 className="font-bold">Add Product Category</h3>
<Field label="Name">
<input className="field" value={productForm.name} onChange={e=>setProductForm(c=>({...c,name:e.target.value,slug:c.slug||slugify(e.target.value)}))}/>
</Field>
<Field label="Slug">
<input className="field" value={productForm.slug} onChange={e=>setProductForm(c=>({...c,slug:slugify(e.target.value)}))}/>
</Field>
<button disabled={busy||!productForm.name.trim()} className="mt-5 w-full rounded-xl bg-[#111827] py-3 font-semibold text-white">
<Plus className="mr-2 inline" size={14}/>Add Category</button>
</form>:<form onSubmit={createBusiness} className="admin-catalog-form">
<h3 className="font-bold">Add Business Category</h3>
<Field label="Name">
<input className="field" value={businessForm.name} onChange={e=>setBusinessForm(c=>({...c,name:e.target.value,slug:c.slug||slugify(e.target.value)}))}/>
</Field>
<Field label="Slug">
<input className="field" value={businessForm.slug} onChange={e=>setBusinessForm(c=>({...c,slug:slugify(e.target.value)}))}/>
</Field>
<Field label="Description">
<textarea rows={4} className="field" value={businessForm.description} onChange={e=>setBusinessForm(c=>({...c,description:e.target.value}))}/>
</Field>
<label className="mt-4 flex gap-2">
<input type="checkbox" checked={businessForm.active} onChange={e=>setBusinessForm(c=>({...c,active:e.target.checked}))}/>Active</label>
<button disabled={busy||!businessForm.name.trim()} className="mt-5 w-full rounded-xl bg-[#111827] py-3 font-semibold text-white">
<Plus className="mr-2 inline" size={14}/>Add Business Category</button>
</form>}<section className="admin-catalog-card overflow-hidden">
<div className="admin-catalog-toolbar">
<div className="relative flex-1">
<Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2"/>
<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search categories..." className="h-10 w-full rounded-xl border pl-9 pr-3"/>
</div>
<button onClick={()=>void load()} className="rounded-xl border px-3">
<RefreshCw size={15}/>
</button>
</div>{loading?<p className="p-10 text-center">Loading...</p>:error?<p className="p-10 text-center text-red-600">{error}</p>:<div className="overflow-x-auto">
<table className="w-full min-w-[650px] text-left text-sm">
<thead className="bg-gray-50">
<tr>
<th className="px-5 py-3">Name</th>
<th className="px-5 py-3">Slug</th>{mode==="business"&&<th className="px-5 py-3">Status</th>}<th className="px-5 py-3">Actions</th>
</tr>
</thead>
<tbody className="divide-y">{(mode==="product"?productRows:businessRows).map((row:any)=>
<tr key={row.id}>
<td className="px-5 py-4 font-semibold">{row.name}</td>
<td className="px-5 py-4 text-gray-500">{row.slug}</td>{mode==="business"&&<td className="px-5 py-4">{row.active?"Active":"Inactive"}</td>}<td className="px-5 py-4">
<button onClick={()=>setEditing({type:mode,row:{...row}} as Editing)} className="mr-4 text-blue-600">
<Edit3 className="inline" size={13}/> Edit</button>
<button onClick={()=>setDeleteTarget({row,type:mode})} className="text-red-600">
<Trash2 className="inline" size={13}/> Delete</button>
</td>
</tr>)}</tbody>
</table>
</div>}<Pagination page={page} pageSize={pageSize} total={total} totalPages={totalPages} onPageChange={setPage} onPageSizeChange={s=>{setPageSize(s);setPage(1)}}/>
</section>
</div>{editing&&<div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4">
<div className="w-full max-w-md rounded-2xl bg-white p-6">
<div className="flex justify-between">
<h3 className="font-bold">Edit Category</h3>
<button onClick={()=>setEditing(null)}>
<X size={18}/>
</button>
</div>
<Field label="Name">
<input className="field" value={editing.row.name} onChange={e=>setEditing(c=>c?({...c,row:{...c.row,name:e.target.value}} as Editing):c)}/>
</Field>
<Field label="Slug">
<input className="field" value={editing.row.slug} onChange={e=>setEditing(c=>c?({...c,row:{...c.row,slug:e.target.value}} as Editing):c)}/>
</Field>{editing.type==="business"&&<Field label="Description">
<textarea rows={4} className="field" value={editing.row.description??""} onChange={e=>setEditing(c=>c&&c.type==="business"?{...c,row:{...c.row,description:e.target.value}}:c)}/>
</Field>}<button onClick={()=>void save()} disabled={busy} className="mt-5 w-full rounded-xl bg-[#111827] py-3 font-semibold text-white">Save Changes</button>
</div>
</div>}<ConfirmActionDialog open={Boolean(deleteTarget)} title="Delete category?" description={<>The category <strong>{deleteTarget?.row.name}</strong> will be permanently deleted. The backend will block deletion if dependent records must be preserved.</>} confirmLabel="Delete category" busy={busy} onCancel={()=>setDeleteTarget(null)} onConfirm={()=>void remove()}/><style jsx global>{`.field{margin-top:.5rem;min-height:46px;width:100%;border-radius:.75rem;border:2px solid #d8e0e9;background:#fff;padding:.7rem .9rem;outline:none}.field:focus{border-color:#f47524}`}</style>
</div>}
function Pagination({page,pageSize,total,totalPages,onPageChange,onPageSizeChange}:{page:number;pageSize:number;total:number;totalPages:number;onPageChange:(n:number)=>void;onPageSizeChange:(n:number)=>void}){const a=total?((page-1)*pageSize+1):0,b=Math.min(page*pageSize,total);return <div className="flex flex-col gap-3 border-t p-4 sm:flex-row sm:items-center sm:justify-between">
<span className="text-sm">Showing {a}-{b} of {total}</span>
<div className="flex gap-2">
<select value={pageSize} onChange={e=>onPageSizeChange(Number(e.target.value))} className="rounded-xl border px-2">{[10,20,50,100].map(x=>
<option key={x}>{x}</option>)}</select>
<button disabled={page<=1} onClick={()=>onPageChange(page-1)} className="rounded-xl border px-3 disabled:opacity-40">Previous</button>
<span className="px-2 py-2 text-xs">Page {page} of {Math.max(totalPages,1)}</span>
<button disabled={page>=totalPages||!totalPages} onClick={()=>onPageChange(page+1)} className="rounded-xl border px-3 disabled:opacity-40">Next</button>
</div>
</div>}
function Field({label,children}:{label:string;children:React.ReactNode}){return <label className="mt-4 block">
<span className="text-sm font-semibold">{label}</span>{children}</label>}
