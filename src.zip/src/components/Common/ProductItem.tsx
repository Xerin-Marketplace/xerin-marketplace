"use client";
import React from "react";
import Image from "next/image";
import { Product } from "@/types/product";
import { useModalContext } from "@/app/context/QuickViewModalContext";
import { useQuickViewStore } from "@/store/useQuickViewStore";
import { useWishlistStore } from "@/store/useWishlistStore";
import { useAddCartItem, addProductToCartPayload } from "@/hooks/useCartActions";
import { useAddToWishlist } from "@/hooks/useWishlist";
import StarRating from "@/components/Common/StarRating";
import Link from "next/link";
import PriceDisplay from "@/components/shared/PriceDisplay";

const ProductItem = ({ item }: { item: Product }) => {
  const { openModal } = useModalContext();

  const updateQuickView = useQuickViewStore((state) => state.updateQuickView);
  const addCartItem = useAddCartItem();
  const addToWishlist = useAddToWishlist();
  const addItemToWishlistLocal = useWishlistStore((state) => state.addItemToWishlist);

  const hasDiscount = item.price > item.discountedPrice;
  const savingsPercent = hasDiscount
    ? Math.round(((item.price - item.discountedPrice) / item.price) * 100)
    : 0;

  // update the QuickView state
  const handleQuickViewUpdate = () => {
    updateQuickView({ ...item });
  };

  // add to cart
  const handleAddToCart = () => {
    addCartItem.mutate(addProductToCartPayload(item));
  };

  const handleItemToWishList = () => {
    addItemToWishlistLocal({
      ...item,
      status: "available",
      quantity: 1,
    });
    addToWishlist.mutate(String(item.id));
  };

  return (
    <div className="group flex h-full min-w-0 flex-col overflow-hidden rounded-xl border border-gray-3 bg-white shadow-sm transition-all duration-300 hover:shadow-md dark:border-darkTheme-border-color dark:bg-darkTheme-card sm:rounded-2xl sm:hover:-translate-y-1 sm:hover:shadow-lg">
      <div className="relative flex aspect-square items-center justify-center overflow-hidden bg-[#F6F7FB] dark:bg-darkTheme-secondary-bg sm:aspect-auto sm:min-h-[285px]">
        {hasDiscount && (
          <span className="absolute left-2 top-2 z-10 rounded-md bg-orange px-2 py-1 text-[10px] font-bold text-white shadow-sm sm:left-4 sm:top-4 sm:rounded-full sm:px-3 sm:text-xs sm:font-semibold">
            Save {savingsPercent}%
          </span>
        )}

        <button
          onClick={() => handleItemToWishList()}
          disabled={addToWishlist.isPending}
          aria-label="Add to wishlist"
          className="absolute right-2 top-2 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-white/95 text-dark shadow-sm transition-colors duration-200 hover:bg-blue hover:text-white dark:bg-darkTheme-tertiary-bg dark:text-darkTheme-body-color disabled:opacity-50 sm:right-4 sm:top-4"
        >
          <svg
            className="fill-current"
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M3.74949 2.94946C2.6435 3.45502 1.83325 4.65749 1.83325 6.0914C1.83325 7.55633 2.43273 8.68549 3.29211 9.65318C4.0004 10.4507 4.85781 11.1118 5.694 11.7564C5.89261 11.9095 6.09002 12.0617 6.28395 12.2146C6.63464 12.491 6.94747 12.7337 7.24899 12.9099C7.55068 13.0862 7.79352 13.1667 7.99992 13.1667C8.20632 13.1667 8.44916 13.0862 8.75085 12.9099C9.05237 12.7337 9.3652 12.491 9.71589 12.2146C9.90982 12.0617 10.1072 11.9095 10.3058 11.7564C11.142 11.1118 11.9994 10.4507 12.7077 9.65318C13.5671 8.68549 14.1666 7.55633 14.1666 6.0914C14.1666 4.65749 13.3563 3.45502 12.2503 2.94946C11.1759 2.45832 9.73214 2.58839 8.36016 4.01382C8.2659 4.11175 8.13584 4.16709 7.99992 4.16709C7.864 4.16709 7.73393 4.11175 7.63967 4.01382C6.26769 2.58839 4.82396 2.45832 3.74949 2.94946ZM7.99992 2.97255C6.45855 1.5935 4.73256 1.40058 3.33376 2.03998C1.85639 2.71528 0.833252 4.28336 0.833252 6.0914C0.833252 7.86842 1.57358 9.22404 2.5444 10.3172C3.32183 11.1926 4.2734 11.9253 5.1138 12.5724C5.30431 12.7191 5.48911 12.8614 5.66486 12.9999C6.00636 13.2691 6.37295 13.5562 6.74447 13.7733C7.11582 13.9903 7.53965 14.1667 7.99992 14.1667C8.46018 14.1667 8.88401 13.9903 9.25537 13.7733C9.62689 13.5562 9.99348 13.2691 10.335 12.9999C10.5107 12.8614 10.6955 12.7191 10.886 12.5724C11.7264 11.9253 12.678 11.1926 13.4554 10.3172C14.4263 9.22404 15.1666 7.86842 15.1666 6.0914C15.1666 4.28336 14.1434 2.71528 12.6661 2.03998C11.2673 1.40058 9.54129 1.5935 7.99992 2.97255Z"
              fill=""
            />
          </svg>
        </button>

        <Image
          src={item.imgs.previews[0]}
          alt={item.title}
          width={250}
          height={250}
          className="h-auto max-h-[160px] w-auto max-w-[90%] object-contain p-3 transition-transform duration-300 group-hover:scale-[1.03] sm:max-h-[240px] sm:p-8"
        />

        <div className="absolute inset-x-0 bottom-0 hidden translate-y-full items-center justify-center gap-2.5 px-4 pb-5 transition-transform duration-300 group-hover:translate-y-0 sm:flex">
          <button
            onClick={() => {
              openModal();
              handleQuickViewUpdate();
            }}
            aria-label="Quick view product"
            className="flex h-10 w-10 items-center justify-center rounded-md bg-white text-dark shadow-sm transition-colors duration-200 hover:bg-blue hover:text-white dark:bg-darkTheme-tertiary-bg dark:text-darkTheme-body-color"
          >
            <svg
              className="fill-current"
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M8.00016 5.5C6.61945 5.5 5.50016 6.61929 5.50016 8C5.50016 9.38071 6.61945 10.5 8.00016 10.5C9.38087 10.5 10.5002 9.38071 10.5002 8C10.5002 6.61929 9.38087 5.5 8.00016 5.5ZM6.50016 8C6.50016 7.17157 7.17174 6.5 8.00016 6.5C8.82859 6.5 9.50016 7.17157 9.50016 8C9.50016 8.82842 8.82859 9.5 8.00016 9.5C7.17174 9.5 6.50016 8.82842 6.50016 8Z"
                fill=""
              />
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M8.00016 2.16666C4.99074 2.16666 2.96369 3.96946 1.78721 5.49791L1.76599 5.52546C1.49992 5.87102 1.25487 6.18928 1.08862 6.5656C0.910592 6.96858 0.833496 7.40779 0.833496 8C0.833496 8.5922 0.910592 9.03142 1.08862 9.4344C1.25487 9.81072 1.49992 10.129 1.76599 10.4745L1.78721 10.5021C2.96369 12.0305 4.99074 13.8333 8.00016 13.8333C11.0096 13.8333 13.0366 12.0305 14.2131 10.5021L14.2343 10.4745C14.5004 10.129 14.7455 9.81072 14.9117 9.4344C15.0897 9.03142 15.1668 8.5922 15.1668 8C15.1668 7.40779 15.0897 6.96858 14.9117 6.5656C14.7455 6.18927 14.5004 5.87101 14.2343 5.52545L14.2131 5.49791C13.0366 3.96946 11.0096 2.16666 8.00016 2.16666ZM2.57964 6.10786C3.66592 4.69661 5.43374 3.16666 8.00016 3.16666C10.5666 3.16666 12.3344 4.69661 13.4207 6.10786C13.7131 6.48772 13.8843 6.7147 13.997 6.9697C14.1023 7.20801 14.1668 7.49929 14.1668 8C14.1668 8.50071 14.1023 8.79199 13.997 9.0303C13.8843 9.28529 13.7131 9.51227 13.4207 9.89213C12.3344 11.3034 10.5666 12.8333 8.00016 12.8333C5.43374 12.8333 3.66592 11.3034 2.57964 9.89213C2.28725 9.51227 2.11599 9.28529 2.00334 9.0303C1.89805 8.79199 1.8335 8.50071 1.8335 8C1.8335 7.49929 1.89805 7.20801 2.00334 6.9697C2.11599 6.7147 2.28725 6.48772 2.57964 6.10786Z"
                fill=""
              />
            </svg>
          </button>

          <button
            onClick={() => handleAddToCart()}
            disabled={addCartItem.isPending}
            className="inline-flex flex-1 items-center justify-center rounded-md bg-blue px-4 py-[10px] text-sm font-medium text-white transition-colors duration-200 hover:bg-blue-dark disabled:opacity-50"
          >
            {addCartItem.isPending ? "Adding..." : "Add to cart"}
          </button>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-2.5 sm:p-5">
        <div className="mb-2 flex min-w-0 items-center justify-between gap-2 sm:mb-3 sm:gap-3">
          <StarRating rating={item.rating} reviewCount={item.reviewCount ?? item.reviews} size={14} />

          <span className="hidden rounded-full bg-green/10 px-3 py-1 text-xs font-semibold text-green sm:inline-flex">
            Delivery options at checkout
          </span>
        </div>

        <h3
          className="mb-2 line-clamp-2 min-h-[38px] text-[13px] font-semibold leading-[19px] text-dark transition-colors duration-200 hover:text-blue dark:text-white sm:min-h-0 sm:text-base sm:leading-normal"
        >
          <Link href={`/products/${item.id}`}>{item.title}</Link>
        </h3>



        <div className="mt-auto flex min-w-0 items-end justify-between gap-2 sm:gap-4">
          <div>
            <span className="mb-1 hidden text-xs font-medium uppercase tracking-[0.2em] text-dark-4 dark:text-darkTheme-secondary-muted sm:block">
              Price
            </span>
            <span className="flex min-w-0 flex-wrap items-baseline gap-1 text-sm font-extrabold sm:gap-2 sm:text-lg sm:font-semibold">
              <span className="text-[#ef4444] dark:text-white sm:text-dark">
                <PriceDisplay amount={item.discountedPrice} sourceCurrency={item.currency} />
              </span>
              <span className="text-[10px] text-dark-4 line-through dark:text-darkTheme-secondary-muted sm:text-sm">
                <PriceDisplay amount={item.price} sourceCurrency={item.currency} />
              </span>
            </span>
          </div>

          <button
            onClick={() => {
              openModal();
              handleQuickViewUpdate();
            }}
            className="hidden items-center justify-center rounded-md border border-gray-3 px-4 py-2 text-sm font-medium text-dark transition-colors duration-200 hover:bg-dark hover:text-white dark:border-darkTheme-border-color dark:text-darkTheme-body-color dark:hover:bg-darkTheme-tertiary-bg sm:inline-flex"
          >
            Quick view
          </button>
        </div>

        <button
          type="button"
          onClick={handleAddToCart}
          disabled={addCartItem.isPending}
          className="mt-2 flex h-10 w-full items-center justify-center rounded-lg bg-orange px-3 text-xs font-bold text-white transition hover:bg-orange-dark disabled:cursor-not-allowed disabled:opacity-50 sm:hidden"
        >
          {addCartItem.isPending ? "Adding..." : "Add to cart"}
        </button>
      </div>
    </div>
  );
};

export default ProductItem;