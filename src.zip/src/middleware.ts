import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const withBrowserPermissions = (response: NextResponse) => {
  response.headers.set(
    "Permissions-Policy",
    "geolocation=(self), camera=(), microphone=()",
  );
  return response;
};

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  const authPresent = request.cookies.get("xerin_auth_present")?.value === "1";
  const adminPresent = request.cookies.get("xerin_admin_present")?.value === "1";
  const sellerPresent = request.cookies.get("xerin_seller_present")?.value === "1";
  const logisticsPresent = request.cookies.get("xerin_logistics_present")?.value === "1";

  if (pathname.startsWith("/admin")) {
    if (!adminPresent) {
      const signinUrl = new URL("/signin", request.url);
      signinUrl.searchParams.set("redirect", pathname);
      return withBrowserPermissions(NextResponse.redirect(signinUrl));
    }
  }

  if (pathname.startsWith("/logistics")) {
    if (!logisticsPresent) {
      const signinUrl = new URL("/signin", request.url);
      signinUrl.searchParams.set("redirect", pathname);
      return withBrowserPermissions(NextResponse.redirect(signinUrl));
    }
  }

  if (pathname.startsWith("/seller/dashboard")) {
    if (!sellerPresent && !adminPresent) {
      const signinUrl = new URL("/signin", request.url);
      signinUrl.searchParams.set("redirect", pathname);
      return withBrowserPermissions(NextResponse.redirect(signinUrl));
    }
  }

  return withBrowserPermissions(NextResponse.next());
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
