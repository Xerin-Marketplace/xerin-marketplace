import { ArrowRight, Home, ShoppingBag } from "lucide-react";
import Link from "next/link";

export default function NotFound() {
  return (
    <main className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-neutral-950 px-4 py-16 text-white sm:px-6 lg:px-8">
      {/* Split background: orange band top, black base */}
      <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-orange-600 via-orange-500 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neutral-950/40 to-neutral-950" />

      {/* Decorative circles */}
      <div className="pointer-events-none absolute -left-20 top-10 h-72 w-72 rounded-full bg-yellow-400 opacity-20 blur-3xl" />
      <div className="pointer-events-none absolute -right-16 bottom-10 h-72 w-72 rounded-full bg-orange-500 opacity-20 blur-3xl" />

      <div className="relative z-10 mx-auto flex w-full max-w-xl flex-col items-center text-center">
        {/* Marketplace icon badge */}
        <div className="mb-8 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-orange-500 to-yellow-400 shadow-lg shadow-orange-900/50 ring-4 ring-white/10">
          <ShoppingBag size={34} strokeWidth={1.8} className="text-neutral-950" />
        </div>

        <p className="mb-3 text-xs font-bold uppercase tracking-widest text-orange-400">
          Error 404
        </p>

        <h1 className="text-6xl font-extrabold leading-none tracking-tight text-white sm:text-7xl">
          Page Not Found
        </h1>

        <p className="mt-6 max-w-md text-sm leading-7 text-neutral-400 sm:text-base">
          Sorry, we couldn&apos;t find the page you&apos;re looking for. It may
          have been moved, sold out, or the link may be outdated.
        </p>

        <div className="mt-10 flex w-full flex-col items-center justify-center gap-3 sm:flex-row">
          <Link
            href="/"
            className="group inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-500 to-yellow-400 px-8 text-sm font-semibold text-neutral-950 shadow-lg shadow-orange-900/40 transition hover:shadow-xl hover:shadow-orange-800/50 sm:w-auto"
          >
            <Home size={18} />
            Back to marketplace
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
          </Link>

          <Link
            href="/shop-with-sidebar"
            className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-full border border-white/15 bg-white/5 px-8 text-sm font-semibold text-white backdrop-blur-sm transition hover:border-orange-400/50 hover:bg-white/10 sm:w-auto"
          >
            <ShoppingBag size={18} />
            Browse products
          </Link>
        </div>

        <div className="mt-10 h-px w-24 bg-gradient-to-r from-transparent via-white/20 to-transparent" />

        <p className="mt-6 text-xs text-neutral-500">
          Error code: 404 &middot; Page not found
        </p>
      </div>
    </main>
  );
}